#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector col_mean(NumericMatrix X) {
  int m = X.nrow();
  int n = X.ncol();
  NumericVector out(n);
  for(int i = 0; i < m; ++i) {
    out = out + X(i,_);
  }
  out = out / m;
  return out;
}
